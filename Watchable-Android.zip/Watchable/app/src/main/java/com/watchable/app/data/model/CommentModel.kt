package com.watchable.app.data.model

import com.google.firebase.Timestamp

data class Comment(
    val id: String = "",
    val mediaId: String = "",
    val userId: String = "",
    val userName: String = "",
    val text: String = "",
    val timestamp: Timestamp? = null,
    val repliesCount: Int = 0,
    val likes: Int = 0,
    val dislikes: Int = 0,
    val userReaction: String? = null
)

data class Reply(
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val text: String = "",
    val timestamp: Timestamp? = null
)
