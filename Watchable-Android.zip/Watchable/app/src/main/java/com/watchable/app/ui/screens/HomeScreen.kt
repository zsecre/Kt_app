package com.watchable.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.watchable.app.data.model.MediaItem
import com.watchable.app.data.model.MediaType
import com.watchable.app.ui.components.FeaturedCarousel
import com.watchable.app.ui.components.MediaRow
import com.watchable.app.viewmodel.HomeViewModel

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToDetail: (String, String) -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    fun navigate(item: MediaItem) {
        val type = when (item.type) {
            MediaType.MOVIE -> "movie"
            MediaType.TV_SHOW -> "tv"
            MediaType.ANIME -> "anime"
        }
        onNavigateToDetail(item.id, type)
    }

    if (state.isLoading) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = androidx.compose.ui.Alignment.Center
        ) {
            CircularProgressIndicator(color = com.watchable.app.ui.theme.BrandCyan)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        item {
            FeaturedCarousel(
                items = state.featured,
                onItemClick = { navigate(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp)
            )
        }

        item { Spacer(Modifier.height(24.dp)) }

        if (state.trendingMovies.isNotEmpty()) {
            item {
                MediaRow(
                    title = "Trending Movies",
                    items = state.trendingMovies,
                    onItemClick = { navigate(it) }
                )
                Spacer(Modifier.height(20.dp))
            }
        }

        if (state.trendingTv.isNotEmpty()) {
            item {
                MediaRow(
                    title = "Trending TV Shows",
                    items = state.trendingTv,
                    onItemClick = { navigate(it) }
                )
                Spacer(Modifier.height(20.dp))
            }
        }

        if (state.topAnime.isNotEmpty()) {
            item {
                MediaRow(
                    title = "Top Anime",
                    items = state.topAnime,
                    onItemClick = { navigate(it) }
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
