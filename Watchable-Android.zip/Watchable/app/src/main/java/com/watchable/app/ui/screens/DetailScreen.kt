package com.watchable.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.firebase.Timestamp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.watchable.app.data.model.*
import com.watchable.app.data.repository.MediaRepository
import com.watchable.app.ui.theme.BrandCyan
import com.watchable.app.ui.theme.StarYellow
import com.watchable.app.viewmodel.MediaViewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun DetailScreen(
    mediaId: String,
    mediaType: String,
    mediaViewModel: MediaViewModel,
    onBack: () -> Unit
) {
    val watchlist by mediaViewModel.watchlist.collectAsState()
    val scope = rememberCoroutineScope()
    val repo = remember { MediaRepository() }

    var item by remember { mutableStateOf<MediaItem?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    val isInWatchlist = watchlist.any { it.mediaId == mediaId }

    LaunchedEffect(mediaId, mediaType) {
        isLoading = true
        item = when (mediaType) {
            "movie" -> runCatching { repo.getPopularMovies().firstOrNull { it.id == mediaId } }.getOrNull()
                ?: runCatching { repo.getTrendingMovies().firstOrNull { it.id == mediaId } }.getOrNull()
            "tv" -> runCatching { repo.getPopularTvShows().firstOrNull { it.id == mediaId } }.getOrNull()
                ?: runCatching { repo.getOnTheAirTvShows().firstOrNull { it.id == mediaId } }.getOrNull()
            "anime" -> runCatching { repo.getTopAnime().firstOrNull { it.id == mediaId } }.getOrNull()
                ?: runCatching { repo.getCurrentSeasonAnime().firstOrNull { it.id == mediaId } }.getOrNull()
            else -> null
        }
        item?.let { mediaViewModel.addToHistory(it) }
        isLoading = false
    }

    var comments by remember { mutableStateOf<List<Comment>>(emptyList()) }
    var commentText by remember { mutableStateOf("") }
    val username by mediaViewModel.username.collectAsState()
    val db = Firebase.firestore
    val auth = Firebase.auth

    LaunchedEffect(mediaId) {
        runCatching {
            auth.signInAnonymously().await()
            db.collection("comments").document(mediaId)
                .collection("entries")
                .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .limit(30)
                .addSnapshotListener { snapshot, _ ->
                    if (snapshot != null) {
                        comments = snapshot.documents.mapNotNull { doc ->
                            runCatching {
                                Comment(
                                    id = doc.id,
                                    mediaId = mediaId,
                                    userId = doc.getString("userId") ?: "",
                                    userName = doc.getString("userName") ?: "Anonymous",
                                    text = doc.getString("text") ?: "",
                                    timestamp = doc.getTimestamp("timestamp"),
                                    repliesCount = (doc.getLong("repliesCount") ?: 0).toInt()
                                )
                            }.getOrNull()
                        }
                    }
                }
        }
    }

    fun postComment() {
        val text = commentText.trim()
        if (text.isBlank() || text.length > 350) return
        val uid = auth.currentUser?.uid ?: return
        commentText = ""
        scope.launch {
            runCatching {
                db.collection("comments").document(mediaId)
                    .collection("entries")
                    .add(
                        hashMapOf(
                            "mediaId" to mediaId,
                            "userId" to uid,
                            "userName" to (username ?: "Anonymous"),
                            "text" to text,
                            "timestamp" to Timestamp.now(),
                            "repliesCount" to 0
                        )
                    ).await()
            }
        }
    }

    if (isLoading) {
        Box(
            modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator(color = BrandCyan) }
        return
    }

    val currentItem = item
    if (currentItem == null) {
        Box(
            modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Content not found", color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = onBack) { Text("Go Back", color = BrandCyan) }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth().height(380.dp)) {
                AsyncImage(
                    model = currentItem.backdropPath ?: currentItem.posterPath,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Black.copy(alpha = 0.3f), Color.Black.copy(alpha = 0.95f))
                        )
                    )
                )
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                ) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
                IconButton(
                    onClick = { scope.launch { mediaViewModel.toggleWatchlist(currentItem) } },
                    modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                ) {
                    Icon(
                        if (isInWatchlist) Icons.Default.Bookmark else Icons.Outlined.BookmarkAdd,
                        "Watchlist",
                        tint = if (isInWatchlist) BrandCyan else Color.White
                    )
                }
                Column(
                    modifier = Modifier.align(Alignment.BottomStart).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        currentItem.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Star, null, tint = StarYellow, modifier = Modifier.size(16.dp))
                            Text(String.format("%.1f", currentItem.voteAverage), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        if (currentItem.releaseDate != null) {
                            Text(currentItem.releaseDate.take(4), color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(BrandCyan)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                when (currentItem.type) {
                                    MediaType.MOVIE -> "Movie"
                                    MediaType.TV_SHOW -> "TV Show"
                                    MediaType.ANIME -> "Anime"
                                },
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (currentItem.overview.isNotBlank()) {
                    Text("Overview", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Text(
                        currentItem.overview,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 22.sp
                    )
                }
            }
        }

        item {
            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            Spacer(Modifier.height(12.dp))
            Text(
                "Comments (${comments.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = commentText,
                    onValueChange = { if (it.length <= 350) commentText = it },
                    placeholder = { Text("Add a comment...") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrandCyan,
                        cursorColor = BrandCyan
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { postComment() })
                )
                IconButton(
                    onClick = { postComment() },
                    enabled = commentText.trim().isNotBlank()
                ) {
                    Icon(Icons.Default.Send, "Send", tint = if (commentText.trim().isNotBlank()) BrandCyan else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        items(comments) { comment ->
            CommentItem(comment = comment, currentUserId = Firebase.auth.currentUser?.uid)
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun CommentItem(comment: Comment, currentUserId: String?) {
    val isOwn = comment.userId == currentUserId
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier.size(28.dp).clip(RoundedCornerShape(8.dp)).background(BrandCyan),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        comment.userName.firstOrNull()?.uppercaseChar()?.toString() ?: "A",
                        fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 12.sp
                    )
                }
                Text(comment.userName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = if (isOwn) BrandCyan else MaterialTheme.colorScheme.onBackground)
                if (isOwn) {
                    Text("(you)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text(comment.text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground)
        }
    }
}
