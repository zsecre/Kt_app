package com.watchable.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.watchable.app.data.model.MediaItem
import com.watchable.app.data.repository.MediaRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class HomeUiState(
    val featured: List<MediaItem> = emptyList(),
    val trendingMovies: List<MediaItem> = emptyList(),
    val trendingTv: List<MediaItem> = emptyList(),
    val topAnime: List<MediaItem> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

class HomeViewModel : ViewModel() {
    private val repository = MediaRepository()

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState

    init {
        loadHome()
    }

    fun loadHome() {
        viewModelScope.launch {
            _uiState.value = HomeUiState(isLoading = true)
            try {
                val featuredDeferred = async { repository.getTrendingAll() }
                val moviesDeferred = async { repository.getTrendingMovies() }
                val tvDeferred = async { repository.getTrendingTv() }
                val animeDeferred = async { repository.getTopAnime() }

                _uiState.value = HomeUiState(
                    featured = featuredDeferred.await().take(8),
                    trendingMovies = moviesDeferred.await().take(10),
                    trendingTv = tvDeferred.await().take(10),
                    topAnime = animeDeferred.await().take(10),
                    isLoading = false
                )
            } catch (e: Exception) {
                _uiState.value = HomeUiState(isLoading = false, error = e.message)
            }
        }
    }
}
