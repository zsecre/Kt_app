package com.watchable.app.data.repository

import com.watchable.app.data.model.*
import com.watchable.app.data.remote.JikanClient
import com.watchable.app.data.remote.TmdbClient

class MediaRepository {
    private val tmdb = TmdbClient.api
    private val jikan = JikanClient.api

    suspend fun getTrendingAll(): List<MediaItem> = runCatching {
        tmdb.getTrending().results.map { movie ->
            val type = if (movie.name != null && movie.title == null) MediaType.TV_SHOW else MediaType.MOVIE
            movie.toMediaItem(type)
        }
    }.getOrDefault(emptyList())

    suspend fun getPopularMovies(): List<MediaItem> = runCatching {
        tmdb.getPopularMovies().results.map { it.toMediaItem(MediaType.MOVIE) }
    }.getOrDefault(emptyList())

    suspend fun getTopRatedMovies(): List<MediaItem> = runCatching {
        tmdb.getTopRatedMovies().results.map { it.toMediaItem(MediaType.MOVIE) }
    }.getOrDefault(emptyList())

    suspend fun getNowPlayingMovies(): List<MediaItem> = runCatching {
        tmdb.getNowPlayingMovies().results.map { it.toMediaItem(MediaType.MOVIE) }
    }.getOrDefault(emptyList())

    suspend fun getUpcomingMovies(): List<MediaItem> = runCatching {
        tmdb.getUpcomingMovies().results.map { it.toMediaItem(MediaType.MOVIE) }
    }.getOrDefault(emptyList())

    suspend fun getPopularTvShows(): List<MediaItem> = runCatching {
        tmdb.getPopularTvShows().results.map { it.toMediaItem(MediaType.TV_SHOW) }
    }.getOrDefault(emptyList())

    suspend fun getTopRatedTvShows(): List<MediaItem> = runCatching {
        tmdb.getTopRatedTvShows().results.map { it.toMediaItem(MediaType.TV_SHOW) }
    }.getOrDefault(emptyList())

    suspend fun getOnTheAirTvShows(): List<MediaItem> = runCatching {
        tmdb.getOnTheAirTvShows().results.map { it.toMediaItem(MediaType.TV_SHOW) }
    }.getOrDefault(emptyList())

    suspend fun getTopAnime(): List<MediaItem> = runCatching {
        jikan.getTopAnime().data.map { it.toMediaItem() }
    }.getOrDefault(emptyList())

    suspend fun getCurrentSeasonAnime(): List<MediaItem> = runCatching {
        jikan.getCurrentSeasonAnime().data.map { it.toMediaItem() }
    }.getOrDefault(emptyList())

    suspend fun searchMulti(query: String): List<MediaItem> = runCatching {
        val tmdbResults = tmdb.searchMulti(query).results
            .filter { it.mediaType != "person" }
            .map { it.toMediaItem() }
        val animeResults = if (query.length >= 2) {
            jikan.searchAnime(query).data.take(5).map { it.toMediaItem() }
        } else emptyList()
        tmdbResults + animeResults
    }.getOrDefault(emptyList())

    suspend fun getTrendingMovies(): List<MediaItem> = runCatching {
        tmdb.getTrendingMovies().results.map { it.toMediaItem(MediaType.MOVIE) }
    }.getOrDefault(emptyList())

    suspend fun getTrendingTv(): List<MediaItem> = runCatching {
        tmdb.getTrendingTv().results.map { it.toMediaItem(MediaType.TV_SHOW) }
    }.getOrDefault(emptyList())
}
