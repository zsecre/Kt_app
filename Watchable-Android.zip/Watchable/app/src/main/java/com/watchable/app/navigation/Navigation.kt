package com.watchable.app.navigation

import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.watchable.app.ui.screens.*
import com.watchable.app.viewmodel.HomeViewModel
import com.watchable.app.viewmodel.MediaViewModel

sealed class Screen(val route: String) {
    object Onboarding : Screen("onboarding")
    object Main : Screen("main")
    object Detail : Screen("detail/{mediaId}/{mediaType}") {
        fun createRoute(mediaId: String, mediaType: String) = "detail/$mediaId/$mediaType"
    }
}

@Composable
fun WatchableNavHost() {
    val navController = rememberNavController()
    val mediaViewModel: MediaViewModel = viewModel()
    val homeViewModel: HomeViewModel = viewModel()

    val onboardingDone by mediaViewModel.onboardingDone.collectAsState()
    val startDestination = if (onboardingDone) Screen.Main.route else Screen.Onboarding.route

    NavHost(navController = navController, startDestination = startDestination) {
        composable(Screen.Onboarding.route) {
            OnboardingScreen(
                onComplete = { name ->
                    mediaViewModel.setUsername(name)
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Main.route) {
            MainScreen(
                mediaViewModel = mediaViewModel,
                homeViewModel = homeViewModel,
                onNavigateToDetail = { mediaId, mediaType ->
                    navController.navigate(Screen.Detail.createRoute(mediaId, mediaType))
                }
            )
        }

        composable(
            route = Screen.Detail.route,
            arguments = listOf(
                navArgument("mediaId") { type = NavType.StringType },
                navArgument("mediaType") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val mediaId = backStackEntry.arguments?.getString("mediaId") ?: return@composable
            val mediaType = backStackEntry.arguments?.getString("mediaType") ?: return@composable
            DetailScreen(
                mediaId = mediaId,
                mediaType = mediaType,
                mediaViewModel = mediaViewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
