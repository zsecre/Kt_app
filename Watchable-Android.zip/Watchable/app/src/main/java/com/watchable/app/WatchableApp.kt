package com.watchable.app

import android.app.Application
import com.google.firebase.FirebaseApp

class WatchableApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
    }
}
