package com.watchable.app.data.model

import com.google.gson.annotations.SerializedName

data class TmdbMovieResponse(
    @SerializedName("results") val results: List<TmdbMovie>
)

data class TmdbMovie(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String?,
    @SerializedName("name") val name: String?,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    @SerializedName("vote_average") val voteAverage: Double,
    @SerializedName("overview") val overview: String?,
    @SerializedName("release_date") val releaseDate: String?,
    @SerializedName("first_air_date") val firstAirDate: String?,
    @SerializedName("genre_ids") val genreIds: List<Int>?
)

data class TmdbDetailMovie(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String?,
    @SerializedName("name") val name: String?,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    @SerializedName("vote_average") val voteAverage: Double,
    @SerializedName("overview") val overview: String?,
    @SerializedName("release_date") val releaseDate: String?,
    @SerializedName("first_air_date") val firstAirDate: String?,
    @SerializedName("genres") val genres: List<TmdbGenre>?,
    @SerializedName("runtime") val runtime: Int?,
    @SerializedName("number_of_seasons") val numberOfSeasons: Int?,
    @SerializedName("status") val status: String?
)

data class TmdbGenre(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String
)

data class TmdbSearchResponse(
    @SerializedName("results") val results: List<TmdbSearchResult>
)

data class TmdbSearchResult(
    @SerializedName("id") val id: Int,
    @SerializedName("title") val title: String?,
    @SerializedName("name") val name: String?,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    @SerializedName("vote_average") val voteAverage: Double,
    @SerializedName("overview") val overview: String?,
    @SerializedName("release_date") val releaseDate: String?,
    @SerializedName("first_air_date") val firstAirDate: String?,
    @SerializedName("media_type") val mediaType: String?
)

fun TmdbMovie.toMediaItem(type: MediaType): MediaItem = MediaItem(
    id = id.toString(),
    title = title ?: name ?: "Unknown",
    posterPath = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" } ?: "",
    backdropPath = backdropPath?.let { "https://image.tmdb.org/t/p/w780$it" },
    voteAverage = voteAverage,
    overview = overview ?: "",
    type = type,
    releaseDate = releaseDate ?: firstAirDate
)

fun TmdbSearchResult.toMediaItem(): MediaItem {
    val type = when (mediaType) {
        "tv" -> MediaType.TV_SHOW
        else -> MediaType.MOVIE
    }
    return MediaItem(
        id = id.toString(),
        title = title ?: name ?: "Unknown",
        posterPath = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" } ?: "",
        backdropPath = backdropPath?.let { "https://image.tmdb.org/t/p/w780$it" },
        voteAverage = voteAverage,
        overview = overview ?: "",
        type = type,
        releaseDate = releaseDate ?: firstAirDate
    )
}
