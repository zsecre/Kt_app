package com.watchable.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.watchable.app.data.model.MediaItem
import com.watchable.app.data.model.MediaType
import com.watchable.app.ui.components.MediaCard
import com.watchable.app.viewmodel.MediaViewModel

@Composable
fun WatchlistScreen(
    viewModel: MediaViewModel,
    onNavigateToDetail: (String, String) -> Unit
) {
    val watchlist by viewModel.watchlist.collectAsState()

    fun navigate(mediaId: String, type: MediaType) {
        val typeStr = when (type) {
            MediaType.MOVIE -> "movie"
            MediaType.TV_SHOW -> "tv"
            MediaType.ANIME -> "anime"
        }
        onNavigateToDetail(mediaId, typeStr)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        Text(
            text = "My Library",
            style = MaterialTheme.typography.displayLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "${watchlist.size} saved titles",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))

        if (watchlist.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Outlined.BookmarkAdd,
                        null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        "Your watchlist is empty",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        "Add movies, shows & anime to see them here",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(watchlist) { wItem ->
                    val fakeMedia = MediaItem(
                        id = wItem.mediaId,
                        title = wItem.title,
                        posterPath = wItem.posterPath,
                        backdropPath = null,
                        voteAverage = 0.0,
                        overview = "",
                        type = wItem.type
                    )
                    MediaCard(
                        item = fakeMedia,
                        onClick = { navigate(wItem.mediaId, wItem.type) },
                        width = 110.dp
                    )
                }
            }
        }
    }
}
